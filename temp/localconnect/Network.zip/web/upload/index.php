<?php
ini_set("file_uploads", "1");
$baseDir = realpath(dirname(__FILE__)) . '/';
$uploadDir = 'files/';

// Attached file upload
if (isset($_FILES) && isset($_FILES['file']) && is_array($_FILES['file']))		// isset($_REQUEST['upload'])
{ 
  // Get the maximum post file size (must be configured in php.ini)
  $max_file_size = ini_get('post_max_size');
  $suffix = strtolower(trim($max_file_size)[strlen(trim($max_file_size))-1]);
  if ($suffix == 'g') { $max_file_size *= 1024 * 1024 * 1024; }
  else if ($suffix == 'm') { $max_file_size *= 1024 * 1024; }
  else if ($suffix == 'k') { $max_file_size *= 1024; }

  if (!isset($_FILES['file']) || !isset($_FILES)|| !is_array($_FILES['file']) || !$_FILES['file']['tmp_name'] || $_FILES['file']['error'] != UPLOAD_ERR_OK) {
    $errNum = $_FILES['file']['error'];
    $errDesc = "Unknown - #$errNum";
    if ($errNum == UPLOAD_ERR_OK) { $errDesc = "No error(!)"; }
    if ($errNum == UPLOAD_ERR_INI_SIZE) { $errDesc = "Size exceeds upload_max_filesize directive"; }
    if ($errNum == UPLOAD_ERR_FORM_SIZE) { $errDesc = "Size exceeds exceeds the MAX_FILE_SIZE directive"; }
    if ($errNum == UPLOAD_ERR_PARTIAL) { $errDesc = "File only partially uploaded"; }
    if ($errNum == UPLOAD_ERR_NO_FILE) { $errDesc = "No file specified?"; }
    if ($errNum == UPLOAD_ERR_NO_TMP_DIR) { $errDesc = "No 'tmp' directory"; }
    print "<p class=\"error\">ERROR: File wasn't uploaded ($errDesc).</p>\n";

  } else {
      
    $srcFile = $_FILES['file']['tmp_name'];
    $file = basename($_FILES['file']['name']);
    $relativeFile = $uploadDir . $file;
    $destFile = $baseDir . $relativeFile;
    
    $fileOk = false;

    $array = explode(".", $file);
    $ext  = strtolower($array[count($array)-1]);
    if ($ext=="omx") { $fileOk = true; }

	print "<p class=\"info\">File upload debugging information: <br />\n";
	print "name = " . $_FILES['file']['name'] . "<br />\n";
	print "mime = " . $_FILES['file']['type'] . "<br />\n";
	print "size = " . $_FILES['file']['size'] . "<br />\n";
	print "tmp_name = " . $_FILES['file']['tmp_name'] . "<br />\n";
	print "error = " . $_FILES['file']['error'] . "\n";
	print "</p>";
	
    if ($file == ".htaccess" || strpos($file, "..") !== FALSE || strpos($file, "/") !== FALSE || strpos($file, "\\") != FALSE) {
      print "<p class=\"error\">ERROR: File has an invalid name (only data files are allowed).</p>\n";
    } else if (!move_uploaded_file($srcFile, $destFile)) {
      print "<p class=\"error\">ERROR: File upload move failed (check directory permissions)\n";
    } else {
      
      print "<p class=\"success\">SUCCESS: File uploaded ok: <a href=\"" . $uploadDir . $file . "\">" . $file . "</a></p>\n";
      
    }
  
  }

}
else if ($_SERVER['REQUEST_METHOD'] == 'PUT')
{

	$file = (isset($_SERVER['HTTP_X_FILENAME']) ? $_SERVER['HTTP_X_FILENAME'] : "upload.dat");

	if ($file == ".htaccess" || strpos($file, "..") !== FALSE || strpos($file, "/") !== FALSE || strpos($file, "\\") != FALSE) {

		// Error: invalid file name
		http_response_code(400);	// Bad request

	}
	else
	{
		// Open the output file
		$fp = fopen($uploadDir . $file, 'wb');

		// Open the body data
		$bodydata = null;
		if (isset($_SERVER['HTTP_CONTENT_ENCODING']) && $_SERVER['HTTP_CONTENT_ENCODING'] == 'deflate')
		{
			// 'deflate'
			$bodydata = fopen('php://input', 'rb'); $params = array('window' => 15); stream_filter_append($bodydata, 'zlib.inflate', STREAM_FILTER_READ, $params);	// normal zlib headers around deflate
			//$bodydata = fopen('php://input', 'rb'); stream_filter_append($bodydata, 'zlib.inflate', STREAM_FILTER_READ, -1);	// raw deflate only (no zlib headers)
			//$bodydata = fopen('php://filter/zlib.inflate/resource=php://input', 'rb'); 	// raw deflate only (no zlib headers)
		}
		else if (isset($_SERVER['HTTP_CONTENT_ENCODING']) && $_SERVER['HTTP_CONTENT_ENCODING'] == 'gzip')
		{
			// 'gzip' 
			$bodydata = fopen('php://input', 'rb'); fread($bodydata, 10); stream_filter_append($bodydata, 'zlib.inflate', STREAM_FILTER_READ, -1);	// skip gzip header then perform raw deflate only (no zlib headers), ignoring final gzip 8-byte footer (CRC & length)
			//$bodydata = fopen('compress.zlib://php://input', 'rb'); set_time_limit(10 * 60 * 60);  // gzip (but seems to block reads until entire stream available, so must set huge initial timeout)
			//$bodydata = gzopen('php://input', 'rb');	// gzip - must be paired with gzread()/gzclose()
		}
		else
		{
			// Un-encoded
			$bodydata = fopen('php://input', 'rb');
		}
		
		// Transfer streams in chunks
		for (;;)
		{
			// Read data
			$data = fread($bodydata, 128 * 1024);
			if ($data === FALSE || $data === '') { break; }
			fwrite($fp, $data);			
			
			//fflush($fp);			

			set_time_limit(60);		// Allow another 60 seconds
		}

		// Close output stream
		fclose($fp);
		
		// Close input stream
		fclose($bodydata);		
	}
	
}
else
{
	http_response_code(400);	// Bad request
}

?>