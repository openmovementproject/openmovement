<?php
$baseDir = realpath(dirname(__FILE__)) . '/';
$uploadDir = 'files/';
ini_set("file_uploads", "1");
//ini_set("upload_tmp_dir", "/tmp/");
?><!doctype html>
<html>
<head>
  <style>html, body { font-family: sans-serif; }</style>
  <title>File upload</title>
</head>
<body>

<h2>Upload file</h2>

<?php

// Get the maximum post file size (must be configured in php.ini)
$max_file_size = ini_get('post_max_size');
$suffix = strtolower(trim($max_file_size)[strlen(trim($max_file_size))-1]);
if ($suffix == 'g') { $max_file_size *= 1024 * 1024 * 1024; }
else if ($suffix == 'm') { $max_file_size *= 1024 * 1024; }
else if ($suffix == 'k') { $max_file_size *= 1024; }

$formAction = $_SERVER['PHP_SELF'];

print "<p>NOTE: The <code>php.ini</code> file has <code>post_max_size</code> set to " . ($max_file_size/1024/1024) . " MB.</p>\n";

print "<fieldset class=\"upload\">\n";
print "  <legend>Upload Data</legend>\n";
print "  <form enctype=\"multipart/form-data\" action=\"$formAction\" method=\"post\">\n";
print "    <input type=\"hidden\" name=\"MAX_FILE_SIZE\" value=\"" . $max_file_size  . "\" />\n";
print "    Local file: <input name=\"file\" type=\"file\" />\n";
print "    <input type=\"submit\" name=\"upload\" value=\"Upload\" />\n";
print "  </form>\n";
print "</fieldset>\n";

if (isset($_REQUEST['upload'])) {

  if (!isset($_FILES['file']) || !isset($_FILES)|| !is_array($_FILES['file']) || !$_FILES['file']['tmp_name'] || $_FILES['file']['error'] != UPLOAD_ERR_OK) {
    $errNum = $_FILES['file']['error'];
    $errDesc = "Unknown - #$errNum";
    if ($errNum == UPLOAD_ERR_OK) { $errDesc = "No error(!)"; }
    if ($errNum == UPLOAD_ERR_INI_SIZE) { $errDesc = "Size exceeds upload_max_filesize directive"; }
    if ($errNum == UPLOAD_ERR_FORM_SIZE) { $errDesc = "Size exceeds exceeds the MAX_FILE_SIZE directive"; }
    if ($errNum == UPLOAD_ERR_PARTIAL) { $errDesc = "File only partially uploaded"; }
    if ($errNum == UPLOAD_ERR_NO_FILE) { $errDesc = "No file specified?"; }
    if ($errNum == UPLOAD_ERR_NO_TMP_DIR) { $errDesc = "No 'tmp' directory"; }
    print "<p class=\"error\">ERROR: File wasn't uploaded ($errDesc).</p>\n";

  } else {
      
    $srcFile = $_FILES['file']['tmp_name'];
    $file = basename($_FILES['file']['name']);
    $relativeFile = $uploadDir . $file;
    $destFile = $baseDir . $relativeFile;
    
    $fileOk = false;

    $array = explode(".", $file);
    $ext  = strtolower($array[count($array)-1]);
    if ($ext=="omx") { $fileOk = true; }

	print "<p class=\"info\">File upload debugging information: <br />\n";
	print "name = " . $_FILES['file']['name'] . "<br />\n";
	print "mime = " . $_FILES['file']['type'] . "<br />\n";
	print "size = " . $_FILES['file']['size'] . "<br />\n";
	print "tmp_name = " . $_FILES['file']['tmp_name'] . "<br />\n";
	print "error = " . $_FILES['file']['error'] . "\n";
	print "</p>";
	
    if ($file == ".htaccess" || strpos($file, "..") !== FALSE || strpos($file, "/") !== FALSE || strpos($file, "\\") != FALSE) {
      print "<p class=\"error\">ERROR: File has an invalid name (only data files are allowed).</p>\n";
    } else if (!move_uploaded_file($srcFile, $destFile)) {
      print "<p class=\"error\">ERROR: File upload move failed (check directory permissions)\n";
    } else {
      
      print "<p class=\"success\">SUCCESS: File uploaded ok: <a href=\"" . $uploadDir . $file . "\">" . $file . "</a></p>\n";
      
    }
  
  }

}

?>

</body>
</html>

