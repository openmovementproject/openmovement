// OmmManager
/*
The OmmManager class enumerates potential connections, manages existing connections, and allows access to the local data store.  
  Promise<function(Array<OmmConnection>)> OmmManager.getConnections();

Lists potential connections to devices, returning an array of OmmConnection objects.
Two functions allow the application to register to be notified when a device is connected or disconnected.  
To set a callback function to be called when a new connection is discovered:
  void OmmManager.onConnectionAdded(callback:function(OmmConnection));
And, to set a callback function to be called when a connection is removed:
  void OmmManager.onConnectionRemoved(callback:function(OmmConnection));
The manager is used to obtain a reference to the data store:
  Promise<function(OmmStore)> OmmManager.getStore(storeParameters:Object);
Where storeParameters can be null, and is reserved for future use.
*/

var OmmManager = (function () {
	var manager = {};
	//var privateVariable = 1;
    
	// function privateMethod() { ; }
    
	//manager.moduleProperty = 1;

	
	// OmmCommand
	var OmmCommand = function(transmit, expectedPrefix, timeout, callbackSuccess, callbackFailure) {
		var command = {};
		
		// NOTE: line-by-line parsing, any line starting "ERROR:" signifies failure, incoming buffer flushed.
		
		// Parameters
		command.transmit = transmit;
		command.expectedPrefix = expectedPrefix;
		command.timeout = timeout;
		command.callbackSuccess = callbackSuccess;
		command.callbackFailure = callbackFailure;
		command.complete = false;
		
		// 
		command.begin = function(callbackSelfRemove) {
			// TODO: Timeouts?
			setTimeout(function() {
				if (!command.complete) {
					command.complete = true;
					if (callbackSelfRemove) { callbackSelfRemove(); }
					if (callbackFailure) { callbackFailure(); }
				}
			}, command.timeout);
			return command.transmit;
		}
		
		// 
		command.processLine = function(line) {
		
			var expectedIsArray = (Object.prototype.toString.call(command.expectedPrefix) == "[object Array]");
			var wasExpected = false;
			
			if (expectedIsArray) {
			    for (i = 0; i < command.expectedPrefix.length; i++) {
//console.log("EXPECTING " + i + ": " + command.expectedPrefix[i]);
					if (line.indexOf(command.expectedPrefix[i]) === 0) { wasExpected = true; break; }
				}
			} else {
//console.log("EXPECTING: " + command.expectedPrefix);
				if (line.indexOf(command.expectedPrefix) === 0) { wasExpected = true; }
			}
			
//console.log("IN: " + line + (wasExpected ? " [EXPECTED]" : ""));
		
			if (wasExpected) {
				if (callbackSuccess) { 
					if (callbackSuccess(line)) { command.complete = true; }
				}
				else { command.complete = true; }
			} else if (line.indexOf("ERROR:") === 0) {
				command.complete = true;
				if (callbackFailure) { callbackFailure(); }
			}
			
			return command.complete;
		}
		
		return command;
	}

	
	// OmmConnection
	var OmmConnection = function(portInfo) {
		var connection = {};
		
		// Copy fields
		connection.type = portInfo.type;
		connection.port = portInfo.port;
		if (portInfo.serial) { connection.serial = portInfo.serial; }
		if (portInfo.id) { connection.id = portInfo.id; }
		if (portInfo.path) { connection.path = portInfo.path; }
		if (portInfo.mac) { connection.mac = portInfo.mac; }
		
		// Connection information
		connection.websocket = null;
		// Command queue
		connection.commandQueue = [];
		// Buffered input
		connection.inputBuffer = "";
		
		
		// OmmConnection.runNextCommand
		function runNextCommand() {
			// Drain buffer
			// NOTE: Will only want to drain text lines if streaming (keep separate from binary streams and known lines relating to the streams)
			connection.inputBuffer = "";
			
			// If we have another command pending
			if (connection.commandQueue.length > 0) {
				var command = connection.commandQueue[0];
				
				var output = command.begin(function() {
					// Timeout error - remove command from queue
					connection.commandQueue.splice(0, 1);
					
					// Start next command
					runNextCommand();					
				});
				if (connection.websocket != null) {
					connection.websocket.send(output);
				}
				
			}
		}
		
		function queueCommand(command) {
			var runNow = (connection.commandQueue.length == 0);
			connection.commandQueue[connection.commandQueue.length] = command;
			if (runNow) { runNextCommand(); }
		}
		
		function receivedLine(line) {
			// If we have a command pending
			if (connection.commandQueue.length > 0) {
				var command = connection.commandQueue[0];
//console.log("IN (" + command.expectedPrefix + "): " + line);
				// Process the line, return true if command completed (success or fail)
				if (command.processLine(line)) {
					// Remove command from queue
					connection.commandQueue.splice(0, 1);
					
					// Start next command
					runNextCommand();
				}
			}	
			else			
			{
//console.log("IN: " + line);
			}
		}
		
		function receivedData(data) {
		
//console.log("BUFFER: " + connection.inputBuffer + "|" + data);
			
			// Append to buffer
			connection.inputBuffer = connection.inputBuffer + data;
			
			// Parse all lines
			for (;;) {
				// Find the next line end
				var idx = connection.inputBuffer.indexOf('\n');
				var idx2 = connection.inputBuffer.indexOf('\r');
				if (idx2 >= 0 && idx2 < idx) { idx = idx2; }

//console.log("LINE-END-AT: " + idx);
				// Break if none found
				if (idx < 0) { break; }
				
				var line;
				line = connection.inputBuffer.substring(0, idx);
				
				// Consume line from buffer
				connection.inputBuffer = connection.inputBuffer.substring(idx + 1);
//console.log("LINE: " + line);
//console.log("REMAINING-BUFFER: " + connection.inputBuffer);
				if (line.length > 0)
				{					
					receivedLine(line);
				}
			}
		}

		
		function parseDateTime(dateString)
		{
			if (dateString == "0") { return 0; }	// Infinitely early
			if (dateString == "-1") { return -1; }	// Infinitely late
			var year   = parseInt(dateString.substring(0,4));
			var month  = parseInt(dateString.substring(5,7));
			var day    = parseInt(dateString.substring(8,10));
			var hour   = parseInt(dateString.substring(11,13));
			var minute = parseInt(dateString.substring(14,16));
			var second = parseInt(dateString.substring(17,19));
			var date = new Date(year, month-1, day, hour, minute, second, 0);
			return date;
		}
		
		function packDateTime(newTime) {
			if (newTime === null) { newTime = new Date(); }
			if (newTime == 0) { return "0"; }		// Infinitely early
			if (newTime == -1) { return "-1"; }	// Infinitely late
			var timestr = newTime.getFullYear() + "-";
			timestr = timestr + ((newTime.getMonth() + 1 < 10) ? "0" : "") + (newTime.getMonth() + 1) + "-";
			timestr = timestr + ((newTime.getDate() < 10) ? "0" : "") + newTime.getDate() + ",";
			timestr = timestr + ((newTime.getHours() < 10) ? "0" : "") + newTime.getHours() + ":";
			timestr = timestr + ((newTime.getMinutes() < 10) ? "0" : "") + newTime.getMinutes() + ":";
			timestr = timestr + ((newTime.getSeconds() < 10) ? "0" : "") + newTime.getSeconds() + "";
			return timestr;
		}

		
		// OmmConnection.open();
		connection.open = function(callbackSuccess, callbackFailure) {
			
			// Close if currently open
			if (connection.websocket) {
				connection.close();
			}
			
			
			var wsUri = OmmManager.getConnectionUrl() + connection.port;
			
			connection.websocket = new WebSocket(wsUri);
			
			//connection.websocket.binaryType = "blob";
			connection.websocket.binaryType = "arraybuffer";			
			
			connection.websocket.onopen = function(evt) { 
				if (callbackSuccess) { callbackSuccess(); } 
			};
			
			connection.websocket.onclose = function(evt) {
				// TODO: onClose
				;
				connection.websocket = null;
				connection.commandQueue = [];
				connection.inputBuffer = "";
			};
			
			// Buffer incoming port data
			connection.websocket.onmessage = function(evt) {
//console.log("]]] " + evt.data);
				var data = evt.data
				
				// Treat binary data as 8-bit ASCII
				if (data instanceof ArrayBuffer) {
					var bytearray = new Uint8Array(data);
					var i, len = bytearray.length;
					var result = '';
					for (i = 0; i < len; i++) {
					    result += String.fromCharCode(bytearray[i]);
					}
					data = result;
				} 
				
				receivedData(data);
			};
			
			// Error calls failure callback (replace after open?)
			connection.websocket.onerror = function(evt) { 
				connection.websocket = null;
				connection.commandQueue = [];
				connection.inputBuffer = "";
				if (callbackFailure) { callbackFailure(); }
			};
		}
		
		// OmmConnection.close();
		connection.close = function() {
			if (connection.websocket) {
				connection.websocket.close();
				connection.websocket = null;
			}
		}
		
		
		// OmmConnection.getIdentity();
		connection.getIdentity = function(callbackSuccess, callbackFailure) {		
			queueCommand(OmmCommand("\r\nID\r\n", "ID=", 3000, function(line)
			{
				var ret = {};

				// "ID=hardwareName,hardwareVersion,firmwareVersion,deviceId,sessionId"
				var parts = line.substring(line.indexOf('=') + 1).split(",");
				
				//ret.raw = line;
				ret.deviceType = parts[0];
				ret.deviceId = parts[3];
				ret.firmwareVersion = parts[2];
			
				if (callbackSuccess) { callbackSuccess(ret); }
				
				return true;
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}
		
		// OmmConnection.getTime();
		connection.getTime = function(callbackSuccess, callbackFailure) {		
			queueCommand(OmmCommand("\r\nTIME\r\n", "$TIME=", 3000, function(line)
			{
				var value = line.substring(line.indexOf('=') + 1);
				
				// "$TIME=YYYY-MM-DD,hh:mm:ss"
				var dateString = line.substring(6);
								
				var ret = parseDateTime(dateString);
			
				if (callbackSuccess) { callbackSuccess(ret); }
				
				return true;
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}
		
		// OmmConnection.getBattery();
		connection.getBattery = function(callbackSuccess, callbackFailure) {		
			queueCommand(OmmCommand("\r\nSAMPLE 1\r\n", "$BATT=", 3000, function(line)
			{
				var ret = {};

				// "$BATT=718,4207,mV,98,1"
				var parts = line.substring(line.indexOf('=') + 1).split(",");
				
				//ret.raw = line;
				ret.voltage = parts[1] / 1000.0;
				ret.percent = parts[3];
				ret.charging = parts[4];
			
				if (callbackSuccess) { callbackSuccess(ret); }
				
				return true;
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}
		
		// OmmConnection.getSettingsRecording();
		connection.getSettingsRecording = function(callbackSuccess, callbackFailure) {
			var ret = {};
			queueCommand(OmmCommand("\r\nSESSION\r\nHIBERNATE\r\nSTOP\r\n", ["SESSION=", "HIBERNATE=", "STOP="], 6000, function(line)
			{
				var value = line.substring(line.indexOf('=') + 1);

				if (line.indexOf("SESSION") === 0) { ret.sessionId = parseInt(value, 10); }
				else if (line.indexOf("HIBERNATE") === 0) { ret.startTime = parseDateTime(value); }
				else if (line.indexOf("STOP") === 0) { ret.endTime = parseDateTime(value); }
			
				if (typeof ret.sessionId !== "undefined" && typeof ret.startTime !== "undefined"  && typeof ret.endTime !== "undefined") {
					if (callbackSuccess) { callbackSuccess(ret); }
					return true;
				}
				return false;	// more to come
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}

		// OmmConnection.getSettingsSensors();
		connection.getSettingsSensors = function(callbackSuccess, callbackFailure) {
			var ret = {};
			queueCommand(OmmCommand("\r\nRATE A\r\nRATE G\r\nRATE M\r\nRATE P\r\nRATE T\r\n", "RATE=", 6000, function(line)
			{
				var parts = line.substring(line.indexOf('=') + 1).split(",");

				//console.log(JSON.stringify(parts));				
			
				     if (parts[0] == "A") { ret.configAccel = { enabled: parseInt(parts[1]), frequency: parseInt(parts[2]), sensitivity: parseInt(parts[3]) }; }
				else if (parts[0] == "G") { ret.configGyro  = { enabled: parseInt(parts[1]), frequency: parseInt(parts[2]), sensitivity: parseInt(parts[3]) }; }
				else if (parts[0] == "M") { ret.configMag   = { enabled: parseInt(parts[1]), frequency: parseInt(parts[2]), sensitivity: parseInt(parts[3]) }; }
				else if (parts[0] == "P") { ret.configAlt   = { enabled: parseInt(parts[1]), frequency: parseInt(parts[2]), sensitivity: parseInt(parts[3]) }; }
				else if (parts[0] == "T") { ret.configAdc   = { enabled: parseInt(parts[1]), frequency: parseInt(parts[2]), sensitivity: parseInt(parts[3]) }; }
			
				if (typeof ret.configAccel !== "undefined" && typeof ret.configGyro !== "undefined"  && typeof ret.configMag !== "undefined" && typeof ret.configAlt !== "undefined" && typeof ret.configAdc !== "undefined") {
					if (callbackSuccess) { callbackSuccess(ret); }
					return true;
				}
				return false;	// more to come
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}

		// OmmConnection.getSettingsMetadata();
		connection.getSettingsMetadata = function(callbackSuccess, callbackFailure) {
			var ret = [null, null, null, null, null, null];
			queueCommand(OmmCommand("\r\nANNOTATE00\r\nANNOTATE01\r\nANNOTATE02\r\nANNOTATE03\r\nANNOTATE04\r\nANNOTATE05\r\n", ["ANNOTATE00=", "ANNOTATE01=", "ANNOTATE02=", "ANNOTATE03=", "ANNOTATE04=", "ANNOTATE05="], 6000, function(line)
			{
				var value = line.substring(line.indexOf('=') + 1);
				var block = parseInt(line.substring(8, 10), 10);
				
//console.log("METADATA #" + block + "=" + value + " -- raw:" + line);
				
				if (block < ret.length) { ret[block] = value; }
				
				if (ret[0] != null && ret[1] != null && ret[2] != null && ret[3] != null && ret[4] != null && ret[5] != null) {
					var metadata = (ret[0] + ret[1] + ret[2] + ret[3] + ret[4] + ret[5]).trim();
					if (callbackSuccess) { callbackSuccess(metadata); }
					return true;
				}
				return false;	// more to come
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}

		
		// OmmConnection.getSettings();
		// Broken into steps so as to not overwhelm the device input buffer
		connection.getSettings = function(callbackSuccess, callbackFailure) {
			var ret = {};
			
			// Step 1. Recording
			function stepRecording() {
				connection.getSettingsRecording(function (val) {
					ret.sessionId = val.sessionId;
					ret.startTime = val.startTime;
					ret.endTime = val.endTime;
					stepSensors();
				}, function() {
					stepSensors();
				});
			}
			
			// Step 2. Sensors
			function stepSensors() {
				connection.getSettingsSensors(function (val) {
					ret.configAccel = val.configAccel;
					ret.configGyro  = val.configGyro;
					ret.configMag   = val.configMag;
					ret.configAlt   = val.configAlt; 
					ret.configAdc   = val.configAdc;
					stepMetadata();
				}, function() {
					stepMetadata();
				});
			}
			
			// Step 3. Metadata
			function stepMetadata() {
				connection.getSettingsMetadata(function (val) {
					ret.metadata = val;
					stepDone();
				}, function() {
					stepDone();
				});
			}
			
			// Step 4. Done
			function stepDone() {
				callbackSuccess(ret);
			}
			
			// Start it off...
			stepRecording();
		}

		
		// OmmConnection.setSettingsRecording();
		connection.setSettingsRecording = function(settings, callbackSuccess, callbackFailure) {
			var sessionId = (typeof settings.sessionId !== "undefined") ? settings.sessionId : 0;
			var startTime = packDateTime((typeof settings.startTime !== "undefined") ? settings.startTime : packDateTime(-1));
			var endTime   = packDateTime((typeof settings.endTime   !== "undefined") ? settings.endTime   : packDateTime(0));
			
			var command = "\r\nSESSION " + sessionId + "\r\nHIBERNATE " + startTime + "\r\nSTOP " + endTime + "\r\n";

			var count = 0;
			queueCommand(OmmCommand(command, ["SESSION=", "HIBERNATE=", "STOP="], 6000, function(line)
			{
				count++;
				if (count >= 3)
				{
					if (callbackSuccess) { callbackSuccess(); }
					return true;
				}
				return false;	// more to come
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}		

		// OmmConnection.setSettingsSensors();
		connection.setSettingsSensors = function(settings, callbackSuccess, callbackFailure) {
			var sessionId = (typeof settings.sessionId !== "undefined") ? settings.sessionId : 0;
			var startTime = packDateTime((typeof settings.startTime !== "undefined") ? settings.startTime : packDateTime(-1));
			var endTime   = packDateTime((typeof settings.endTime   !== "undefined") ? settings.endTime   : packDateTime(0));
			
			// Add any missing values
			if (typeof settings.configAccel             == "undefined") { settings.configAccel             = {}; } 
			if (typeof settings.configAccel.enabled     == "undefined") { settings.configAccel.enabled     = 1; } 
			if (typeof settings.configAccel.frequency   == "undefined") { settings.configAccel.frequency   = 100; } 
			if (typeof settings.configAccel.sensitivity == "undefined") { settings.configAccel.sensitivity = 8; } 
			if (typeof settings.configGyro              == "undefined") { settings.configGyro              = {}; } 
			if (typeof settings.configGyro.enabled      == "undefined") { settings.configGyro.enabled      = 1; } 
			if (typeof settings.configGyro.frequency    == "undefined") { settings.configGyro.frequency    = 100; } 
			if (typeof settings.configGyro.sensitivity  == "undefined") { settings.configGyro.sensitivity  = 2000; } 
			if (typeof settings.configMag               == "undefined") { settings.configMag               = {}; } 
			if (typeof settings.configMag.enabled       == "undefined") { settings.configMag.enabled       = 1; } 
			if (typeof settings.configMag.frequency     == "undefined") { settings.configMag.frequency     = 10; } 
			if (typeof settings.configMag.sensitivity   == "undefined") { settings.configMag.sensitivity   = 0; } 
			if (typeof settings.configAlt               == "undefined") { settings.configAlt               = {}; } 
			if (typeof settings.configAlt.enabled       == "undefined") { settings.configAlt.enabled       = 1; } 
			if (typeof settings.configAlt.frequency     == "undefined") { settings.configAlt.frequency     = 1; } 
			if (typeof settings.configAlt.sensitivity   == "undefined") { settings.configAlt.sensitivity   = 0; } 
			if (typeof settings.configAdc               == "undefined") { settings.configAdc               = {}; } 
			if (typeof settings.configAdc.enabled       == "undefined") { settings.configAdc.enabled       = 1; } 
			if (typeof settings.configAdc.frequency     == "undefined") { settings.configAdc.frequency     = 1; } 
			if (typeof settings.configAdc.sensitivity   == "undefined") { settings.configAdc.sensitivity   = 0; } 

			// Construct command
			var command = "\r\n";
			command = command + "RATE A " + settings.configAccel.enabled + " " + settings.configAccel.frequency + " " + settings.configAccel.sensitivity + "\r\n"; 
			command = command + "RATE G " + settings.configGyro.enabled  + " " + settings.configGyro.frequency  + " " + settings.configGyro.sensitivity  + "\r\n"; 
			command = command + "RATE M " + settings.configMag.enabled   + " " + settings.configMag.frequency   + " " + settings.configMag.sensitivity   + "\r\n"; 
			command = command + "RATE P " + settings.configAlt.enabled   + " " + settings.configAlt.frequency   + " " + settings.configAlt.sensitivity   + "\r\n"; 
			command = command + "RATE T " + settings.configAdc.enabled   + " " + settings.configAdc.frequency   + " " + settings.configAdc.sensitivity   + "\r\n"; 

			var count = 0;
			queueCommand(OmmCommand(command, "RATE=", 6000, function(line)
			{
				count++;
				if (count >= 5)
				{
					if (callbackSuccess) { callbackSuccess(connection); }
					return true;
				}
				return false;	// more to come
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}		


		// OmmConnection.setSettingsMetadata();
		connection.setSettingsMetadata = function(settings, callbackSuccess, callbackFailure) {
			var count = 0;
			var text = (typeof settings.metadata !== "undefined") ? settings.metadata : "";
			command = "\r\n";
			for (i = 0; i < 6; i++)
			{
				var strip = "";
				var start = i * 32;
				var end = (i + 1) * 32;
				if (start < text.length)
				{
					if (end > text.length) { end = text.length; }
					{
						strip = text.substring(start, end);
					}
				}
				command = command + "ANNOTATE0" + i + ":" + strip.trim() + "\r\n";
			}

//		console.log("METADATA: " + command);
			
			queueCommand(OmmCommand(command, ["ANNOTATE00=", "ANNOTATE01=", "ANNOTATE02=", "ANNOTATE03=", "ANNOTATE04=", "ANNOTATE05="], 6000, function(line)
			{
				var value = line.substring(line.indexOf('=') + 1);
				var block = parseInt(line.substring(8, 10), 10);
				
//console.log("METADATA #" + block + "=" + value + " -- raw:" + line);
				
				//if (block < ret.length) { ret[block] = value; }
				
				count++;
				if (count >= 6) {
					if (callbackSuccess) { callbackSuccess(); }
					return true;
				}
				
				return false;	// more to come
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}

		// OmmConnection.setSettingsCommit();
		connection.setSettingsCommit = function(settings, callbackSuccess, callbackFailure) {		
			queueCommand(OmmCommand("\r\nCOMMIT\r\n", "COMMIT", 5000, function(line)
			{
				if (line == "COMMIT")
				{
					if (callbackSuccess) { callbackSuccess(); }
					return true;
				}
				else
				{
					return false;
				}
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}

		// Broken into steps so as to not overwhelm the device input buffer
		connection.setSettings = function(settings, callbackSuccess, callbackFailure) {
			
			// Step 1. Recording
			function stepRecording() {
				connection.setSettingsRecording(settings, function (val) {
					stepSensors();
				}, function() {
					stepSensors();
				});
			}
			
			// Step 2. Sensors
			function stepSensors() {
				connection.setSettingsSensors(settings, function (val) {
					stepMetadata();
				}, function() {
					stepMetadata();
				});
			}
			
			// Step 3. Metadata
			function stepMetadata() {
				connection.setSettingsMetadata(settings, function (val) {
					stepCommit();
				}, function() {
					stepCommit();
				});
			}
			
			// Step 4. Commit
			function stepCommit() {
				connection.setSettingsCommit(settings, function (val) {
					stepDone();
				}, function() {
					stepDone();
				});
			}
			
			// Step 5. Done
			function stepDone() {
				callbackSuccess();
			}
			
			// Start it off...
			stepRecording(settings);
		}


		// OmmConnection.getMemory();
		connection.getMemory = function(callbackSuccess, callbackFailure) {	
		
			// Must be on a connection with a path
			if (typeof connection.path === 'undefined') { callbackFailure(); return; }
			
			// AJAX request
			var xmlhttp;
			xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
				{
					var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
					memory = {};
					// Read relevant parts
					if (typeof response.free     !== 'undefined') { memory.free     = response.free;     }
					if (typeof response.capacity !== 'undefined') { memory.capacity = response.capacity; }
					if (typeof response.used     !== 'undefined') { memory.used     = response.used;     }
					if (callbackSuccess) { callbackSuccess(memory); }
				}
				else if (xmlhttp.readyState == 4)
				{
					if (callbackFailure) { callbackFailure(); }
				}
			}
			xmlhttp.open("GET", "http://" + manager.getDomain() + "/memory?path=" + connection.path, true);
			xmlhttp.send();	
		}
		
		
		// OmmConnection.getFiles();
		connection.getFiles = function(callbackSuccess, callbackFailure) {	
		
			// Must be on a connection with a path
			if (typeof connection.path === 'undefined') { callbackFailure(); return; }
			
			// AJAX request
			var xmlhttp;
			xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
				{
					var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
					
					var files = [];
					for (var i = 0; i < response.files.length; i++)
					{
						// Make OmmConnection object
						var fileData = response.files[i];
						var file = {};
						
						// Read relevant parts
						if (typeof fileData.name             !== 'undefined') { file.name             = fileData.name            ; }
						if (typeof fileData.filename         !== 'undefined') { file.filename         = fileData.filename        ; }
						if (typeof fileData.size             !== 'undefined') { file.size             = fileData.size            ; }
						if (typeof fileData.lastModifiedDate !== 'undefined') { file.lastModifiedDate = new Date(fileData.lastModifiedDate * 1000); }
						if (typeof fileData.createdDate      !== 'undefined') { file.createdDate      = new Date(fileData.createdDate * 1000); }
						if (typeof fileData.archive          !== 'undefined') { file.archive          = (fileData.archive != 0); }
						
						files.push(file);
					}
					if (callbackSuccess) { callbackSuccess(files); }
				}
				else if (xmlhttp.readyState == 4)
				{
					if (callbackFailure) { callbackFailure(); }
				}
			}
			xmlhttp.open("GET", "http://" + manager.getDomain() + "/listing?path=" + connection.path, true);
			xmlhttp.send();	
		}		
					
		// OmmConnection.format();
		connection.format = function(callbackSuccess, callbackFailure) {		
			queueCommand(OmmCommand("\r\nFORMAT Q\r\n", "FORMAT: Complete.", 10000, function(line)
			{
				if (callbackSuccess) { callbackSuccess(); }
				return true;
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}

		// OmmConnection.setLed();
		connection.setLed = function(led, callbackSuccess, callbackFailure) {		
			queueCommand(OmmCommand("\r\nLED " + led + "\r\n", "LED=", 3000, function(line)
			{
				if (callbackSuccess) { callbackSuccess(); }
				return true;
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}
		
		// OmmConnection.setTime();
		connection.setTime = function(newTime, callbackSuccess, callbackFailure) {		
		
			newTime = ((typeof newTime === 'undefined') ? null : newTime);	
			var timestr = packDateTime(newTime);
						
			queueCommand(OmmCommand("\r\nTIME " + timestr + "\r\n", "$TIME=", 3000, function(line)
			{
				if (callbackSuccess) { callbackSuccess(); }
				return true;
			}, 
			function() {
				if (callbackFailure) { callbackFailure(); }
			}));		
		}
		
		return connection;
	}
	
	
	manager.getDomain = function() {
		return "localhost:1234";
	}
	
	manager.getConnectionUrl = function() {
		// TODO: Get domain from loader after this script is loaded.
		return "ws://" + manager.getDomain() + "/serial?port=";
	}

	
	// OmmManager.getConnections()
	manager.getConnections = function(callbackSuccess, callbackFailure) {	
		// AJAX request
		var xmlhttp;
		xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
		xmlhttp.onreadystatechange = function() {
			if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
			{
				var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
				if (response.ports)
				{
					var connections = [];
					for (var i = 0; i < response.ports.length; i++)
					{
						// Make OmmConnection object
						connection = OmmConnection(response.ports[i]);						
						connections.push(connection);
					}
					if (callbackSuccess) { callbackSuccess(connections); }
				}
				else
				{
					if (callbackFailure) { callbackFailure(); }
				}
			}
			else if (xmlhttp.readyState == 4)
			{
				if (callbackFailure) { callbackFailure(); }
			}
		}
		xmlhttp.open("GET", "http://" + manager.getDomain() + "/ports", true);
		xmlhttp.send();	
	}
	
    // A function allows the application to register to be notified when the system device connections may have changed (such as a when a device is connected or disconnected).  To set a callback function to be called when a connections may have been changed (the application can then call getConnections() again to identify any changes):
	// OmmManager.onConnectionsChanged(callback:function());
	//manager.connectionsChangedCallback = null;
	//manager.onConnectionsChanged = function(callback) { 
	//	manager.connectionsChangedCallback = callback;
	//}
	
	// OmmConnection
	var OmmStore = function() {
		var store = {};
	
	
		// OmmStore.getFiles();
		store.getFiles = function(callbackSuccess, callbackFailure) {
		
			// AJAX request
			var xmlhttp;
			xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
				{
					var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
					
					var files = [];
					for (var i = 0; i < response.files.length; i++)
					{
						// Make OmmConnection object
						var fileData = response.files[i];
						var file = {};
						
						// Read relevant parts
						if (typeof fileData.name             !== 'undefined') { file.name             = fileData.name            ; }
						if (typeof fileData.filename         !== 'undefined') { file.filename         = fileData.filename        ; }
						if (typeof fileData.size             !== 'undefined') { file.size             = fileData.size            ; }
						if (typeof fileData.lastModifiedDate !== 'undefined') { file.lastModifiedDate = new Date(fileData.lastModifiedDate * 1000); }
						if (typeof fileData.createdDate      !== 'undefined') { file.createdDate      = new Date(fileData.createdDate * 1000); }
						if (typeof fileData.archive          !== 'undefined') { file.archive          = (fileData.archive != 0); }
						
						files.push(file);
					}
					if (callbackSuccess) { callbackSuccess(files); }
				}
				else if (xmlhttp.readyState == 4)
				{
					if (callbackFailure) { callbackFailure(); }
				}
			}
			xmlhttp.open("GET", "http://" + manager.getDomain() + "/listing", true);
			xmlhttp.send();				
		};

		
		// OmmStore.remove(storeFileName:String);
		store.remove = function(filename, callbackSuccess, callbackFailure) {
		
			// AJAX request
			var xmlhttp;
			xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
				{
					var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
					
					if (callbackSuccess) { callbackSuccess(); }
				}
				else if (xmlhttp.readyState == 4)
				{
					if (callbackFailure) { callbackFailure(); }
				}
			}
			xmlhttp.open("POST", "http://" + manager.getDomain() + "/remove?file=" + filename, true);
			xmlhttp.send();				
		};
		
		
		// OmmStore.getMetadata(fileName:String);  // OmmMetadata { deviceInformation:OmmDeviceInformation, settings:OmmSettings, fileInformation:OmmFile }
		store.getMetadata = function(filename, callbackSuccess, callbackFailure) {
		
			// AJAX request
			var xmlhttp;
			xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
				{
					var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
					
					// Pass response through
					if (callbackSuccess) { callbackSuccess(response); }
				}
				else if (xmlhttp.readyState == 4)
				{
					if (callbackFailure) { callbackFailure(); }
				}
			}
			xmlhttp.open("GET", "http://" + manager.getDomain() + "/metadata?file=" + filename, true);
			xmlhttp.send();				
		};

		
		// OmmStore.beginDownload(storeFilename:String, sourceFilename:String, callbackSuccess:function, callbackFailure:function);
		store.beginDownload = function(storeFilename, sourceFilename, callbackSuccess, callbackFailure) {
		
			if (typeof storeFilename == 'undefined' || storeFilename == null || storeFilename == "") {
				if (callbackFailure) { callbackFailure('No store filename specified.'); }
				return;
			}
			if (typeof sourceFilename == 'undefined' || sourceFilename == null || sourceFilename == "") {
				if (callbackFailure) { callbackFailure('No source filename specified.'); }
				return;
			}
			
			// AJAX request
			var xmlhttp;
			xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
				{
					var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
					
					// Pass response through
					if (callbackSuccess) { callbackSuccess(response); }
				}
				else if (xmlhttp.readyState == 4)
				{
					if (callbackFailure) { callbackFailure(); }
				}
			}
			xmlhttp.open("POST", "http://" + manager.getDomain() + "/download?storeFile=" + storeFilename + "&sourceFile=" + sourceFilename, true);
			xmlhttp.send();				
		};

		
		// OmmStore.beginUpload(storeFilename:String, uploadParameters:Object, callbackSuccess:function, callbackFailure:function);
		store.beginUpload = function(storeFilename, uploadParameters, callbackSuccess, callbackFailure) {
		
			if (typeof storeFilename == 'undefined' || storeFilename == null || storeFilename == "") {
				if (callbackFailure) { callbackFailure('No store filename specified.'); }
				return;
			}
			if (typeof uploadParameters == 'undefined' || typeof uploadParameters.url == 'undefined' || uploadParameters.url == null || uploadParameters.url == "") {
				if (callbackFailure) { callbackFailure('No URL specified (uploadParameters.url).'); }
				return;
			}
		
			// AJAX request
			var xmlhttp;
			xmlhttp = (window.XMLHttpRequest) ? (new XMLHttpRequest()) : (new ActiveXObject("Microsoft.XMLHTTP"));
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
				{
					var response = (JSON && JSON.parse) ? JSON.parse(xmlhttp.responseText) : eval('(' + xmlhttp.responseText + ')');
					
					// Pass response through
					if (callbackSuccess) { callbackSuccess(response); }
				}
				else if (xmlhttp.readyState == 4)
				{
					if (callbackFailure) { callbackFailure(); }
				}
			}
			xmlhttp.open("POST", "http://" + manager.getDomain() + "/upload?storeFile=" + storeFilename + "&destUrl=" + uploadParameters.url, true);
			xmlhttp.send();				
		};

		
		return store;
	}();
	
	// OmmManager.getStore()
	manager.getStore = function() { 
		return OmmStore;
	}
	
	// OmmManager.start()
	manager.start = function (callbackSuccess, callbackFail) {
	    // TODO: Start status update connection here
		if (callbackSuccess) { callbackSuccess(); }
	};

	return manager;
}());
