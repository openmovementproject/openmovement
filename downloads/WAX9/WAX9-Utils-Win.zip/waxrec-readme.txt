
Example usage:
  waxrec.exe \\.\COM## -init "\r\nRATE X 1 50\r\nDATAMODE 1\r\nSTREAM\r\n" -log -tee >mylogfile.csv

...where COM## is the Bluetooth COM port the device is attached to, and 'mylogfile.csv' is the log file you want to create.

Output lines are of the format:

  $WAX9,receivedTime,sampleNumber,sampleTime,accelX,accelY,accelZ,gyroX,gyroY,gyroZ

Where:

  "$WAX9" denotes the line as a data line
  receivedTime is the time on the PC that the packet was received in "YYYY-MM-DD hh:mm:ss.000" format.
  sampleNumber is the number of the packet (wraps to 0 after 65535)
  sampleTime is the device's internal timestamp for the sample in seconds (wraps to 0 after 65535)
  accelX/Y/Z are in units of G, or 9.81 m/s/s (when the default accelerometer range setting is used, otherwise the units are incorrect)
  gyroX/Y/Z are in units of degrees/second (when the default gyro sensitivity setting is used, otherwise the units are incorrect)
  magX/Y/Z are in units of uT

