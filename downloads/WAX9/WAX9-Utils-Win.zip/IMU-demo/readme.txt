IMU Demo
~~~~~~~~


Command-line options
--------------------

-in !   Auto-connect to a USB COM port (default) (this method will not work with WAX9 devices)
-in \\.\COM##  Connect to the specified COM port (can be found in Device Manager)
-in @   Auto-connect to the first found Bluetooth COM port (this may not be one in range)
-in @11:22:33:44:55:66  Connect to the Bluetooth COM port with the specified MAC address


Note that the demo currently requires 100Hz sample rate.

The default initialization string is:

  -init "\r\nRATE M 1 80\r\nRATE X 1 100\r\nDATAMODE 1\r\nSTREAM\r\n"


Keys
----

Space   Reset IMU
F11     Toggle full-screen
F5      Toggle graph overlay
F6      Toggle movement integration (experimental)
