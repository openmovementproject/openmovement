/*************************************************/
/** Title:  live.js                             **/
/** Author: Sam Mitchell Finnigan               **/
/** Email:  samuel.finnigan@ncl.ac.uk           **/
/** Date:   2013-2014                           **/
/**                                             **/
/** Sets up a websocket and plots received      **/
/** packets to a Flot graph                     **/
/**                                             **/
/*************************************************/

// Debug
var LOG_PACKETS = false;
var PLOT_ALL_PIR_ENERGY = true;

// Time
var tz_offset = -(new Date().getTimezoneOffset()) * 60 * 1000;
var pageload = (+new Date()) + tz_offset;
var duration = 5 * 60 * 1000;			// Display 5 mins of data
var MAX_DURATION = 2 * 60 * 60 * 1000;	// 2h Max
var MIN_DURATION = 1 * 60 * 1000;

var MAX_UNSIGNED_SHORT = 0xffff;

// Timed tasks
var mutex_maintainDuration=false;
var tid_maintainDuration=-1;
var tid_draw=-1;

var updates = false;	// Only copy data if there are updates
var updateSpeed = 250;	// milliseconds
var slowDown = 20;		// Slow draw speed when displaying more data

// Websocket client
var ws;
var retries = 5;

// Data for flot to plot in array
var drawData = [[]];

// RX'd data storage
var data = {
	rssi: {},
	temp: {},
	light: {},
	battery: {},
	humidity: {},
	pir: {},
	energy: {},
	sw: {}
};

// Last RX packet for calculation of graphing data
var data_last = {
	pir: {},
	energy: {},
	sw: {}
};

// Packet Type enum
e_pktType = {	
	AES_KEY_PKT_TYPE 	: 0,	/* Packet type for encryption packets */
	DECODED_BAX_PKT		: 1,	/* BAX2.0 format */
	DECODED_BAX_PKT_PIR	: 2,	/* BAX2.0 format */
	DECODED_BAX_PKT_SW	: 3,	/* BAX2.0 format */
	BAX_NAME_PKT		: 4		/* Name type pkt format */
}

// Tick formaters for specialised data types
var switchFormatter = function(val, axis) {
	if(val == 0 )
		return "Open";
	else if(val == 1 )
		return "Closed";
	else 
		return "";
}

var pirFormatter = function(val, axis) {
	if(val == 1)
		return "Event";
	else
		return "";
}

// Plot settings for each data type
var plot_setting = {
	rssi:     { points: true,  lines: true,  fill: false, step: false },
	temp:     { points: true,  lines: true,  fill: false, step: false },
	light:    { points: true,  lines: true,  fill: false, step: false },
	battery:  { points: true,  lines: true,  fill: false, step: false },
	humidity: { points: true,  lines: true,  fill: false, step: false },
	pir:      { points: true,  lines: false, fill: false, step: false },
	energy:   { points: true,  lines: true,  fill: false, step: false },
	sw:       { points: true,  lines: true,  fill: false, step: true  }
};

// Formatters and value settings for y-axis
var tick_setting = {
	pir: { min: 0.5,  max: 1.5, tickFormatter: pirFormatter,    minTickSize: 1, ticks: [0, 1, 2] },
	sw:  { min: -0.5, max: 1.5, tickFormatter: switchFormatter, minTickSize: 1, ticks: [-0.5, 0, 1, 1.5] }
};

var redraw_checkboxes = false;
var checkboxes = {};

var colours = { i:0 };	// Just contains colour counter at first

var total_rx = 0;
var encrypted_rx = 0;

// Page stuff
var container = $("#chart");
var textarea = $("#messages");
var choiceContainer = $("#choices");
var ui = $(".chartcontainer");

// Max data points displayable by the chart
var field = window.location.hash.substring(1);
if(!field) {
	window.location.hash = "temp";
	field = "temp";
}

// Blocking CSS (can this be done with classes?)
var ERR_CSS = {
	'border': '1px solid #e00',
};

// Set blockUI defaults:
$.blockUI.defaults.overlayCSS.backgroundColor = '#999';
$.blockUI.defaults.overlayCSS.opacity = .5;

$.blockUI.defaults.css['background']            = '#fff';
$.blockUI.defaults.css['text-align']            = 'center';
$.blockUI.defaults.css['padding']               = '5px';
$.blockUI.defaults.css['min-width']             = '100px';
$.blockUI.defaults.css['border']                = '1px solid #555';
$.blockUI.defaults.css['border-radius']         = '10px';
$.blockUI.defaults.css['-moz-border-radius']    = '10px' ;
$.blockUI.defaults.css['-webkit-border-radius'] = '10px';

/* Main function */
var main = function() {
	
	// Block using jQuery blocking plugin
	ui.block({ 
		message: '<p>Connecting... </p><p><img src="css/loading.gif" /></p>'
	});

	updateDuration();
	wsConnect();
	draw();
	tooltipInitialise();
};




/* STOMP WEBSOCKETS */
var wsConnect = function() {

	if ("WebSocket" in window) {	// Pure websocket
		ws = new WebSocket("ws://" + window.location.hostname + "/ws");
	}
	else 
	{	// Backwards compatibility with older browsers:
		//  use SockJS implementation instead of the browser's native implementation
		ws = new SockJS("ws://" + window.location.hostname + "/ws");
	}

	ws.onopen = function() {
		console.info("Connected to WS");

		// Block using jQuery blocking plugin
		ui.block({ 
			message: '<p>Waiting for data... </p><p><img src="css/loading.gif" /></p>', 
		}); 
	};

	ws.onerror = function() {
		
		console.error("Websocket connection error");

		// Check for dropped connection and try reconnecting
		ws.close();

		ui.block({ 
			message: "<p>Connection lost! :(<hr/></p><p><input type='button' class='btn' onClick='wsConnect()' value='Reconnect?'/></p>",
			css: ERR_CSS, 
		}); 

		if( --retries > 0 )
		{
			wsConnect();
		}
	};

	ws.onmessage = function(event) {
		parse(event.data);
	};

	ws.onclose = function() {
		console.log("WS Closed");
	};

};


/* Close connection */
var wsDisconnect = function() {
	ws.close();

	ui.block({ 
		message: "<p>Connection closed.<hr/></p><p><input type='button' class='btn' onClick='wsConnect()' value='Reconnect?'/></p>", 
	});

	console.log("Manually disconnected");

	retries = 5;	// Reset retries
}


/* DATA PARSING */
// Parse a received message and populate data structures
var parse = function(msg) {
	
	$("#messages").html(msg);

	var array = msg.split(',');

	// Update total received field on packet received
	total_rx++;
	$("#total_msgs").html(total_rx);

	var timestamp = (+new Date()) + tz_offset;
	
	var msg = {
		date        : array[0],
		time        : array[1],
		addr        : array[2],
		rssi        : +array[3],
		pktType     : +array[4],
		seq         : +array[5],
		xmit        : +array[6],
		battery     : +array[7],
		humidity    : +array[8],
		temp        : +(array[9] / 10),
		light       : +array[10],
		pirCount    : +array[11],
		pirEnergy   : +array[12],
		swCount     : parseInt(array[13])
	};
	
	if(LOG_PACKETS)
		console.log(msg);

	if(array.length < 12)	// Encrypted packet will have 1 element.
	{
		if( encrypted_rx++ == 0 && total_rx == encrypted_rx) {
			ui.block({ 
				message: "<p>Encrypted packet received. <br/>Are all of your sensors correctly paired?</p>",
			});

		}

		if(encrypted_rx == 1)
		{
			$("#encrypted_rx").removeClass("hidden");
		}

		//console.log("Encrypted packet RX");
		return 0;
	}

	var sensor = msg.addr;
	var new_color = false;

	// for { temp, light, battery, etc }
	for( var data_type in data ) {

		// Check and define sensors dynamically
		if(! data[data_type].hasOwnProperty(msg.addr)) {
			data[data_type][msg.addr] = [];
			new_color = true;
		}

		// Maintain a checkbox for sensors
		if(! checkboxes.hasOwnProperty(msg.addr)) {
			checkboxes[msg.addr] = "checked";
			redraw_checkboxes = true;
		}
	}

	// Do the same for "last value" storage for PIR graph calc etc
	for( var data_type in data_last ) {
		if(! data_last[data_type].hasOwnProperty(msg.addr)) {
			data_last[data_type][msg.addr] = [];
		}
	}


	// Hard-code colors for graph so flot doesn't redraw them
	if(new_color)
		colours[msg.addr] = colours.i++;
	
	// Insert new values (forcing numeric type with +)
	data.rssi[msg.addr].push(     [+timestamp, +msg.rssi] );
	data.temp[msg.addr].push(     [+timestamp, +msg.temp] );
	data.light[msg.addr].push(    [+timestamp, +msg.light] );
	data.battery[msg.addr].push(  [+timestamp, +msg.battery] );
	data.humidity[msg.addr].push( [+timestamp, +msg.humidity] );

	data_last.pir[msg.addr].push(    [+timestamp, +msg.pirCount] );
	data_last.energy[msg.addr].push( [+timestamp, +msg.pirEnergy] );
	data_last.sw[msg.addr].push(     [+timestamp, +msg.swCount] );

	processDiffs(msg, +timestamp);

	updates = true;
	
	// Unblock on first message of selected type
	if( total_rx >= 1 )
	{
		ui.unblock();
		choiceContainer.removeClass("hidden");
	}
};


var processDiffs = function(msg, timestamp) {

	// PIR diffs
	var len = data_last.pir[msg.addr].length - 1;
	if( len > 1 )
	{
		var thisPIR = data_last.pir[msg.addr][len][1];
		var lastPIR = data_last.pir[msg.addr][len-1][1];

		// Detect 65k short 2byte wrap
		if( lastPIR > thisPIR ) 
			thisPIR += MAX_UNSIGNED_SHORT;

		// Calculate trigger state for PIR
		var pirTrig = (thisPIR - lastPIR == 0) ? 0 : 1;

		// For PIR, we only plot triggers.
		// A point on the graph means an activation
		if(pirTrig > 0) {
			data.pir[msg.addr].push([+timestamp, pirTrig]);
			data_last.pir[msg.addr].shift();
		} else {
			data_last.pir[msg.addr].pop();	// Trim array back to 2 elems
		}
	} 
	else if(msg.pktType == e_pktType.DECODED_BAX_PKT_PIR) 
	{
		data.pir[msg.addr].push([+timestamp, 1]);
	}

	// Energy 
	len = data_last.energy[msg.addr].length - 1;
	if( len > 1 )
	{
		var thisEnergy = data_last.energy[msg.addr][len][1];
		var lastEnergy = data_last.energy[msg.addr][len-1][1];

		var thisTime = data_last.energy[msg.addr][len][0];
		var lastTime = data_last.energy[msg.addr][len-1][0];

		if( lastEnergy > thisEnergy ) 
			thisEnergy += MAX_UNSIGNED_SHORT;

		// Calculate difference in energy count, making sure to normalise
		//  the data as PIR energy counts will be higher for sensors with a 
		//  lower transmission frequency. The multiplication by 100 is for de-
		//  decimalising the value, although this means the scale is arbitrary.
		var timeDiff = thisTime - lastTime;
		var energyDiff = ((thisEnergy - lastEnergy) / timeDiff) * 100;

		// Update difference, discard packets with no difference
		if(energyDiff > 0 || PLOT_ALL_PIR_ENERGY) {
			data.energy[msg.addr].push([+timestamp, energyDiff]);
			data_last.energy[msg.addr].shift();
		} else {
			data_last.energy[msg.addr].pop();
		}
	} 
	else if(msg.pktType == e_pktType.DECODED_BAX_PKT_PIR) 
	{
		data.energy[msg.addr].push([+timestamp, 0]);
	}

	// Switch
	len = data_last.sw[msg.addr].length - 1;
	if( len > 1 )
	{
		var thisSwitch = data_last.sw[msg.addr][len][1];
		var lastSwitch = data_last.sw[msg.addr][len-1][1];

		if( lastSwitch > thisSwitch ) 
			thisSwitch += MAX_UNSIGNED_SHORT;

		// Calculate trigger states for switch
		var swTrig = thisSwitch % 2;	// 0 = closed, 1 = open

		// For switches, we plot the last seen state, open or closed
		if(thisSwitch != lastSwitch)
		{
			data.sw[msg.addr].push([+timestamp, swTrig]);
			
			if(data_last.sw[msg.addr].length == 3)
				data_last.sw[msg.addr].shift();
		} else {
			data_last.sw[msg.addr].pop();
		}
	}
	else if(msg.pktType == e_pktType.DECODED_BAX_PKT_SW)
	{
		data.sw[msg.addr].push([+timestamp, swTrig]);
	}
}

// Populate an array with received data
var getData = function(field) 
{
	if(updates) 
	{
		drawData = [];
		for( sensor in data[field] ) {
			if(checkboxes[sensor] == "checked")
				drawData.push({data: data[field][sensor], label:sensor, color:colours[sensor]});
		}
		updates = false;
	}

	return drawData;
};


/** Duration maintainence **/

//This has potential to be quite a CPU-intensive function
//Run every minute after duration has expired
var maintainDuration = function() {

	// Do not run this if it's already running
	if(mutex_maintainDuration) return -1;
	mutex_maintainDuration = true;

	var start = (+new Date()) + tz_offset;

	clearTimeout(tid_maintainDuration);
	console.warn("Optimising graph data...");

	// for { temp, light, battery, etc }
	// While head of queue for each sensor is older than duration of graph, shift elements
	for(var data_type in data )
		for(var sensor in data[data_type])
			if( typeof data[data_type][sensor][0] !== "undefined" && data[data_type][sensor][0].length > 0 )
				while( data[data_type][sensor][0][0] < (start - duration))
					data[data_type][sensor].shift();

	var end = (+new Date()) + tz_offset;
	console.warn("Graph optimised in " + (end- start) + " ms"); // log total time
	
	updates = true;	// Redraw
	mutex_maintainDuration = false;
	tid_maintainDuration = setTimeout(maintainDuration, 60*1000);
};


// Recalculate duration
var updateDuration = function() {
	
	$("#duration").val(duration / 1000 / 60)

	var now = (+new Date()) + tz_offset;
	
	// If we haven't triggered maintainDuration() yet, bring it forward:
	if(pageload + duration > now) {
		var newDuration = duration - (now - pageload);
		clearTimeout(tid_maintainDuration);
		tid_maintainDuration = setTimeout(maintainDuration, newDuration);

		// log
		var minutes = Math.round(newDuration/1000/60);
		var seconds = Math.round((+((newDuration/1000/60).toFixed(2)) % 1) * 60);
		console.info("optimise in: " + minutes + "m" + seconds + "s" +
						", data: " + (duration/1000/60) + "m, update: " + (1000/updateSpeed).toFixed(3) + "fps");
	} else {
		maintainDuration();
	}
};


var incDuration = function() {
	if(duration < MAX_DURATION)	{ // 1 hr max
		duration+=60*1000;
		updateSpeed += slowDown;
	}
	updateDuration();
};

var decDuration = function() {
	if(duration > MIN_DURATION) {	// 1 min minimum
		duration-=60*1000;
		updateSpeed -= slowDown;
	}
	updateDuration();
};

var setDuration = function(select) {
	var val = select.options[select.selectedIndex].value;
	console.warn("Update duration to " + val + "mins");
	duration = val * 60 * 1000;
	updateSpeed = 150 + (val * slowDown);

	updateDuration();
};


/** CHECKBOX UPDATES **/
var updateChoices = function() {
	for(var series in checkboxes) {
		checkboxes[series] = "";
	}

	$(choiceContainer).find("input:checked").each(function() {
		var box = $(this).attr("name");
		checkboxes[box] = "checked";
	});

	redraw();
};


// insert checkboxes 
var drawCheckboxes = function(type) {
		choiceContainer.empty();
		$.each(checkboxes, function(key, val) {
			var chk_str = "<label for='" + key + "' class='col6'><input type='" + type + "' name='" + key + "' ";
			if(val=="checked") chk_str += "checked='" + val + "' ";
			chk_str += "id='" + key + "'></input>" + key + "</label>";

			choiceContainer.append(chk_str);
		});

		$(choiceContainer).find("input").click(function() { updateChoices(); });
};



/** PLOTTING **/
var draw = function() {

	// Prevent calling multiple times
	clearTimeout(tid_draw);

	var date = new Date();
	var timestamp = date.getTime() + tz_offset;

	var plot_options = {
		grid: {
			borderWidth: 1,
			minBorderMargin: 20,
			labelMargin: 10,
			hoverable: true,
		},
		legend: { show: true, position: "nw" },
		lines: {
			show:  plot_setting[field].lines, 
			fill:  plot_setting[field].fill,
			steps: plot_setting[field].step
		},
		points: { show: plot_setting[field].points },
		xaxis: { 
			mode: "time",
			minTickSize: [5, "second"],
			timeformat: "%H:%M:%S",
			max: +(timestamp),
			min: +(timestamp - duration),
		}
	};

	// Sparse y-axis plot options select
	if (typeof tick_setting[field] !== "undefined")
	{
		plot_options.yaxis = {
			min: tick_setting[field].min,
			max: tick_setting[field].max,
			tickFormatter : tick_setting[field].tickFormatter,
			minTickSize :   tick_setting[field].minTickSize,
			ticks :         tick_setting[field].ticks
		};
	}

	$.plot(container, getData(field), plot_options);

	if(redraw_checkboxes) {
		drawCheckboxes("checkbox");	// Redraw checkboxes
		redraw_checkboxes = false;
	}

	tid_draw = setTimeout(draw, updateSpeed);
};


var redraw = function() {
	console.warn("Redrawing");
	updates = true;
	redraw_checkboxes = true;
	draw();
};


/** Tooltip on data points */
var showTooltip = function(x, y, contents) {
    $('<div id="tooltip">' + contents + '</div>').css( {
        position: 'absolute',
        display: 'none',
        top: y + 5,
        left: x + 5,
        border: '1px solid #DCA',
        padding: '2px',
        'background-color': '#fffAF0',
        opacity: 0.80
    }).appendTo("body").fadeIn(200);
}

var tooltipInitialise = function() {

    var previousPoint = null;
    container.bind("plothover", function (event, pos, item) {
        $("#x").text(pos.x.toFixed(2));
        $("#y").text(pos.y.toFixed(2));

        if (item) {
            if (previousPoint != item.dataIndex) {
                previousPoint = item.dataIndex;
                
                $("#tooltip").remove();
                var x = item.datapoint[0],
                    y = item.datapoint[1].toFixed(2);
                
                var msg = "<strong>Sensor: </strong>" + item.series.label + "<br />" +
                		  "<strong>Time: </strong>" + new Date(x - tz_offset) + "<br />" +
                		  "<strong>Value:</strong>" + y;

                showTooltip(item.pageX, item.pageY, msg);
            }
        }
        else {
            $("#tooltip").remove();
            previousPoint = null;            
        }
    });

    $("#placeholder").bind("plotclick", function (event, pos, item) {
        if (item) {
            console.log("clicked point " + item.dataIndex + " in " + item.series.label + ".");
            plot.highlight(item.series, item.datapoint);
        }
    });
}



