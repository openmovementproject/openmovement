/* util.js */
var $ = function(e){return [].slice.call(document.querySelectorAll(e))};

// Helper from http://youmightnotneedjquery.com/
function document_ready(fn) {
	if(document.addEventListener)
		document.addEventListener('DOMContentLoaded', fn);
	else
		document.attachEvent('onreadystatechange', function() { if (document.readyState === 'interactive') fn();	});
}

/* Cookie Tools. */
function deleteCookie(name) {
	var d = new Date();
	var expires = "expires=" + +d.setDate(d.getDate()-1);
	var loc = window.location.pathname;
//	var dir = loc.substring(0, loc.lastIndexOf('/')+1);
	document.cookie = name + "=;" + expires + "; path=" + "/"; //dir;
}

function clearListCookies() {   
	var cookies = document.cookie.split(";");
	for (var i=0; i < cookies.length; i++) {   
		deleteCookie(cookies[i].split("=")[0]);
	}
}
// Update display with success/fail message based on cookie set by server
function updateMsgs() {
	if(document.cookie.indexOf("update") == -1) return false;
	
	var e; 
	if(document.cookie.indexOf("update=fail") != -1) {
		console.log("update=fail");
		e = document.getElementById("update_fail");
	} else if (document.cookie.indexOf("update=ok") != -1) {
		console.log("update=ok");
		e = document.getElementById("update_ok");
	}
	
	if(typeof e != "undefined") {
		console.log("hidden class removed on " + e);
		e.className = e.className.replace(/\bhidden\b/,'');
	}
	deleteCookie("update");
}

/* Fade in animation (minified) */
function visible(e){ return (e.className.indexOf("hidden") == -1) }
function show(e){ if(!visible(e)) e.className = e.className.replace(/\bhidden\b/,''); }
function hide(e){ if(visible(e)) e.className += " hidden"; }
// JS fade in (css-only fade is difficult with display:none)
function fadeIn(e){if(visible(e))return;var t=0;show(e);e.style.opacity=0;e.style.filter="";var n=+(new Date);var r=function(){t+=(new Date-n)/400;e.style.opacity=t;e.style.filter="alpha(opacity="+100*t|0+")";n=+(new Date);if(t<1){window.requestAnimationFrame&&requestAnimationFrame(r)||setTimeout(r,16)}};r()}
