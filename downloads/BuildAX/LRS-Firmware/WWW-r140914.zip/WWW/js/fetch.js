
var byId = function(element) { return document.getElementById(element) }

// Convert from 1970 epoch to 2000 epoch for BAX RTC
var EPOCH_CONVERT = +(new Date("2000-01-01")) / 1000;
// Potential date formats
var rx1 = /(\d{4})[\-\/\.](\d{2})[\-\/\.](\d{2}) (\d{2}):(\d{2}):(\d{2})/;	// Optional seconds
var rx2 = /(\d{4})[\-\/\.](\d{2})[\-\/\.](\d{2}) (\d{2}):(\d{2})/;			// Optional hh:mm
var rx3 = /(\d{4})[\-\/\.](\d{2})[\-\/\.](\d{2})/;							// Base date

var SAMPLE_RANGE_MAX = 65535;
var FILE_SPAN_MAX = 5;

function isInt(n){
    return typeof n === "number" && isFinite(n) && n % 1 === 0;
}

function unixTimeToRTC(jstime) {
	return Math.round(jstime / 1000) - EPOCH_CONVERT;
}

function parseDateTime(string) {
	rx1.lastIndex = rx2.lastIndex = rx3.lastIndex = 0;

	// Attempt to parse yyyy-mm-dd hh:mm
	var d = rx1.exec(string);
	if(d == null) d = rx2.exec(string);
	if(d == null) d = rx3.exec(string);
	if(d == null) return -1;	// If still null, fail.

	if(d.length == 7) {
		return unixTimeToRTC(+new Date(
		    (+d[1]),
		    (+d[2])-1, // Months are 0 indexed
		    (+d[3]),
		    (+d[4]),
		    (+d[5]), 
		    (+d[6])
		));
	}

	if(d.length == 6) {
		return unixTimeToRTC(+new Date(
		    (+d[1]),
		    (+d[2])-1, // Months are 0 indexed
		    (+d[3]),
		    (+d[4]),
		    (+d[5])
		));
	}

	return unixTimeToRTC(+new Date(
	    (+d[1]),
	    (+d[2])-1, // Months are 0 indexed
	    (+d[3])
	));
}


/*Form enable/disable and show/hide code triggered by dropdown onChange*/
function showForm(e, fade) {
	var input;
	var val = e.options[e.selectedIndex].value;
	switch(val)
	{
		/*** Time ***/
		case 'BT':
		case 'TT':
			byId("time_type_bin").disabled = (val == "BT") ? false : true;
			byId('time_type_txt').disabled = (val == "TT") ? false : true;
			input = byId('by_time');
			break;

		/*** File ***/
		case 'BF':
		case 'TF':
			byId('file_type_bin').disabled = (val == "BF") ? false : true;
			byId('file_type_txt').disabled = (val == "TF") ? false : true;
			input = byId('by_file');
			break;

		/*** Sample ***/
		case 'BS':
			input = byId('by_sample_range');
			break;

		/*** Last N ***/
		case 'LS':
			input = byId('sequential');
			break;

		default:
			break;
	}

	// hide all except input
	$('#form_inserts > form').forEach(function(e, i){
		if(e !== input)
			hide(e);
	});
	(fade) ? fadeIn(input) : show(input);
}


/* Validate a range between two integer values */
function validateRange(name, max) {

	var start = parseInt(byId(name + '_start').value);
	var end = parseInt(byId(name + '_end').value);

	console.log("start: "+ start + "; end: " + end);

	// Hide errors (will flash if still errored)
	hide(byId(name + '_order_error'));
	hide(byId(name + '_range_error'));
	hide(byId(name + '_int_error'));

	// Check if integer values
	if(! (isInt(start) && isInt(end))) 
	{
		fadeIn(byId(name + '_int_error'));
		console.error(name + ' params not int: ' + start + ',' + end);
		return false;
	}
	// Sanity-check the parameter order
	else if(start > end)
	{
		fadeIn(byId(name + '_order_error'));
		console.error(name + ' parameter order error');
		return false;
	}
	// Check the number of files requested is less than FILE_SPAN_MAX
	else if(end - start > max) 
	{
		fadeIn(byId(name + '_range_error'));
		console.error(name + ' range span error');
		return false;
	}

	// else, validated OK.
	return true;
}


/* Intercept the GET request to do validation & correctly format timestamps for the server side */
function captureForm(e) {

	if (e.preventDefault) e.preventDefault();

	/* Validate values entered as a means to prevent 400 errors */
	var a = e.elements;
	switch(a[0].value) {
		/* Validate Time Range */
		case 'BT':  // Is the submission type time? (BT / TT)
		case 'TT': 	// Time Range (id="by_time")
			var start = byId('time_start_sub');
			var end = byId('time_end_sub');

			start.value = parseDateTime(a[4].value);
			end.value = parseDateTime(a[5].value);

			// Hide errors (will flash if still errored)
			hide(byId('time_error'));
			hide(byId('order_error'));
			hide(byId('future_error'));

			// Unrecognised parameters?
			if( isNaN(start.value) || isNaN(end.value) || start.value == -1 || end.value == -1 )
			{
				fadeIn(byId('time_error'));
				console.error("Date Parse Error");
				return false;	// Don't submit
			}

			// Parameters in wrong order
			if( start.value > end.value )
			{
				fadeIn(byId('order_error'));
				console.error("Date Order Error");
				return false;
			}

			// Start is in the future?
			if( start.value > unixTimeToRTC(+new Date()) )
			{
				fadeIn(byId('future_error'));
				console.error("Future Date Error");
				return false;
			}

			// else, validated OK.
			break;

		/* Validate File Range */
		case 'BF':
		case 'TF':
			return validateRange('file', FILE_SPAN_MAX);

		/* Validate sample range */
		case 'BS':
			return validateRange('sample', SAMPLE_RANGE_MAX);

		default: // fall through
			break;
	}

	console.info("Validated OK");
	return true;	// Validation OK, submit form
}

document_ready(function() {
	showForm(byId('type'), false);
});
